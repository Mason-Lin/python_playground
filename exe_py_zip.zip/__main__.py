
print("hello world")
